// LOCAL ENVIRONMENT FILE (Ignored by Git)
// DO NOT COMMIT THIS FILE TO VERSION CONTROL
window.AU_ENV = {
  // Your Google Analytics 4 Measurement ID (e.g., G-XXXXXXXXXX)
  GA_MEASUREMENT_ID: 'G-42E5CDVX48',
  // Your Google Analytics 4 API Secret
  GA_API_SECRET: '1LnG_fAwSdSM8yc0m1YFLg'
};
